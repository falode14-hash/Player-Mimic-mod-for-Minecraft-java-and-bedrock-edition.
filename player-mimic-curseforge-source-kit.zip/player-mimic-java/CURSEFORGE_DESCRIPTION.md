# Player Mimic

A creepy humanoid mob for Minecraft Java Edition that stalks players, freezes when observed, and may relocate when unseen.

## Features
- Custom humanoid mob: `playermimic:player_mimic`
- 40 health and 6 attack damage
- Pursues nearby players and uses melee attacks
- Approximate look detection: freezes when a nearby player is looking toward it
- Occasional teleport attempts when unseen
- Custom player-like texture

## Requirements
- Minecraft Java Edition 1.21.1
- NeoForge 21.1.x (developed against 21.1.172)
- Java 21

## How to test
Install the compiled mod JAR in your NeoForge profile's `mods` folder, launch Minecraft, enter a world with cheats enabled, and run:

```mcfunction
/summon playermimic:player_mimic
```

## Known limitations
This is an early release. Look detection is approximate, and the mob does not copy real player account skins. Natural spawning and a spawn egg are not included yet. Compatibility should be tested in-game before release.

## Source
The project source is included in the source repository. Licensed under MIT.
