package com.jethro.playermimic;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

@Mod(PlayerMimicMod.MOD_ID)
public final class PlayerMimicMod {
    public static final String MOD_ID = "playermimic";

    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(Registries.ENTITY_TYPE, MOD_ID);

    public static final DeferredHolder<EntityType<?>, EntityType<PlayerMimicEntity>> PLAYER_MIMIC =
            ENTITY_TYPES.register("player_mimic", () -> EntityType.Builder
                    .of(PlayerMimicEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.95F)
                    .clientTrackingRange(10)
                    .build("player_mimic"));

    public PlayerMimicMod(IEventBus modBus) {
        ENTITY_TYPES.register(modBus);
        modBus.addListener(PlayerMimicEntity::onAttributeCreate);
    }
}
