package com.jethro.playermimic;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;

public class PlayerMimicEntity extends Monster {
    private int unseenTicks = 0;
    private int teleportCooldown = 0;

    public PlayerMimicEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.xpReward = 8;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 40.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.27D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.FOLLOW_RANGE, 32.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.25D);
    }

    public static void onAttributeCreate(EntityAttributeCreationEvent event) {
        event.put(PlayerMimicMod.PLAYER_MIMIC.get(), createAttributes().build());
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.15D, false));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide || !(this.level() instanceof ServerLevel serverLevel)) return;

        Player watcher = findPlayerLookingAtMe();
        if (watcher != null) {
            // Stop movement while directly observed. This is a gameplay approximation,
            // not a perfect human-vision test: it uses view angle and line of sight.
            this.getNavigation().stop();
            this.setDeltaMovement(Vec3.ZERO);
            this.unseenTicks = 0;
            return;
        }

        this.unseenTicks++;
        if (this.teleportCooldown > 0) this.teleportCooldown--;

        // When unseen for a while, occasionally relocate near the current target.
        if (this.unseenTicks > 35 && this.teleportCooldown == 0
                && this.getTarget() instanceof Player target
                && target.isAlive() && this.distanceToSqr(target) > 100.0D) {
            tryStalkTeleport(serverLevel, target);
            this.teleportCooldown = 100;
            this.unseenTicks = 0;
        }
    }

    private Player findPlayerLookingAtMe() {
        for (Player player : this.level().players()) {
            if (!player.isAlive() || player.isSpectator() || player.distanceToSqr(this) > 32.0D * 32.0D) continue;
            if (!player.hasLineOfSight(this)) continue;
            Vec3 toMimic = this.getEyePosition().subtract(player.getEyePosition()).normalize();
            if (player.getLookAngle().dot(toMimic) > 0.94D) return player;
        }
        return null;
    }

    private void tryStalkTeleport(ServerLevel level, Player target) {
        // Try a few safe, open positions around the target; no teleport if none qualify.
        for (int attempt = 0; attempt < 8; attempt++) {
            double angle = this.random.nextDouble() * Math.PI * 2.0D;
            double distance = 7.0D + this.random.nextDouble() * 5.0D;
            double x = target.getX() + Math.cos(angle) * distance;
            double z = target.getZ() + Math.sin(angle) * distance;
            int y = level.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                    (int) Math.floor(x), (int) Math.floor(z));
            BlockPos feet = BlockPos.containing(x, y, z);
            if (level.getBlockState(feet).isAir()
                    && level.getBlockState(feet.above()).isAir()
                    && level.getBlockState(feet.below()).isSolid()) {
                this.teleportTo(x, y, z);
                this.lookAt(target, 180.0F, 30.0F);
                level.broadcastEntityEvent(this, (byte) 46);
                return;
            }
        }
    }

    @Override
    public boolean canBeLeashed() {
        return true;
    }
}
