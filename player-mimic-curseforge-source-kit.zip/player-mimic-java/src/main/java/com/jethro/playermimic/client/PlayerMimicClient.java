package com.jethro.playermimic.client;

import com.jethro.playermimic.PlayerMimicMod;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.api.distmarker.Dist;

@EventBusSubscriber(modid = PlayerMimicMod.MOD_ID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class PlayerMimicClient {
    private PlayerMimicClient() {}

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(PlayerMimicMod.PLAYER_MIMIC.get(), PlayerMimicRenderer::new);
    }

    private static final class PlayerMimicRenderer extends MobRenderer<com.jethro.playermimic.PlayerMimicEntity, HumanoidModel<com.jethro.playermimic.PlayerMimicEntity>> {
        private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
                PlayerMimicMod.MOD_ID, "textures/entity/player_mimic.png");

        private PlayerMimicRenderer(EntityRendererProvider.Context context) {
            super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER)), 0.45F);
        }

        @Override
        public ResourceLocation getTextureLocation(com.jethro.playermimic.PlayerMimicEntity entity) {
            return TEXTURE;
        }
    }
}
