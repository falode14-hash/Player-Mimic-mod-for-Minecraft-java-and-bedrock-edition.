# Player Mimic — Minecraft Java Edition (NeoForge 1.21.1)

A starter mod project for a creepy humanoid mob. It is written for **Minecraft Java Edition 1.21.1**, **NeoForge 21.1.172**, and **Java 21**.

## Features in this starter

- Custom `playermimic:player_mimic` monster entity.
- 40 health and 6 attack damage.
- Targets nearby players and uses melee AI.
- Freezes/stops moving when a nearby player has line of sight and is looking approximately toward it.
- After it has been unseen for a while, it may teleport to a safe open spot around its target if the target is far away.
- A custom 64×64 player-like texture.

**Limitations:** the look test is an approximation based on view angle and line of sight, not true eye-tracking. The mob does not copy a real player's account skin. It currently has no natural spawn rules or spawn egg; use `/summon playermimic:player_mimic` to test it. Teleport behavior is intentionally occasional and only attempts positions with open space and a solid block below.

## Requirements

- Minecraft Java Edition 1.21.1
- NeoForge 21.1.x (project is pinned to 21.1.172)
- Java Development Kit (JDK) 21
- Gradle 8.8+ (or import the project in a compatible IDE and let Gradle sync it)

## Build the mod JAR

1. Install JDK 21 and verify `java -version` reports 21.
2. Install Gradle 8.8 or newer, or open this folder in IntelliJ IDEA and import it as a Gradle project.
3. From this folder run:

   **Windows:** `gradle build`

   **macOS/Linux:** `gradle build`

4. The built mod JAR should appear under `build/libs/` (for example, `playermimic-1.0.0.jar`).
5. Install NeoForge for Minecraft 1.21.1, then copy the JAR into the instance's `mods` folder. Launch the NeoForge profile.

If Gradle is not installed, use the official Gradle installation guide or generate a wrapper from a machine with Gradle installed by running `gradle wrapper --gradle-version 8.10.2`, then use `./gradlew build` (Windows: `gradlew.bat build`). This ZIP does not bundle a Gradle wrapper JAR.

## Test in a world

1. Launch Minecraft with NeoForge 1.21.1 and the built mod installed.
2. Create or load a world with cheats enabled.
3. Run: `/summon playermimic:player_mimic`
4. Look directly at it from within about 32 blocks to test the freeze behavior. Look away and give it time to move or stalk.

## Source layout

- `src/main/java/com/jethro/playermimic/PlayerMimicMod.java` — mod and entity registration
- `src/main/java/com/jethro/playermimic/PlayerMimicEntity.java` — mob AI, looking detection, and stalking teleport
- `src/main/java/com/jethro/playermimic/client/PlayerMimicClient.java` — client renderer registration
- `src/main/resources/assets/playermimic/textures/entity/player_mimic.png` — texture
- `src/main/resources/META-INF/neoforge.mods.toml` — mod metadata

## GitHub

Create a repository and upload the contents of this project folder. Keep the source files and README in the repository so other people can inspect and build it. Do not upload private tokens or personal files.

## License

MIT. See `LICENSE`.
