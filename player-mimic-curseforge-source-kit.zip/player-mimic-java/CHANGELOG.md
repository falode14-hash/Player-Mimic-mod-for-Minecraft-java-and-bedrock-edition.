# Changelog

## 1.0.0 — Initial source release
- Added Player Mimic entity registration and renderer.
- Added player-targeting melee AI.
- Added approximate freeze-when-watched behavior.
- Added occasional unseen teleport behavior.
- Added custom humanoid texture.

Note: This source release has not yet been compiled or tested in-game.
