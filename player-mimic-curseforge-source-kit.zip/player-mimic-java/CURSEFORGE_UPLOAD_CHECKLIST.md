# CurseForge upload checklist

1. Build and test the mod before publishing. Use Java 21 and a compatible Gradle 8.x installation. Run `gradle build` from the project directory.
2. Confirm the compiled JAR appears in `build/libs/` and test it in Minecraft 1.21.1 with NeoForge 21.1.x.
3. Create a Minecraft project on CurseForge: https://www.curseforge.com/
4. Set the game version to Minecraft 1.21.1 and the mod loader to NeoForge.
5. Upload the compiled `.jar` as the mod file. Do not upload the source ZIP as the playable mod file.
6. Use `CURSEFORGE_DESCRIPTION.md` for the project description and `CHANGELOG.md` for release notes.
7. Include a clear mod icon and screenshots, and identify the project as an early release until tested.

Do not claim the file is tested until it has been launched successfully in-game.
